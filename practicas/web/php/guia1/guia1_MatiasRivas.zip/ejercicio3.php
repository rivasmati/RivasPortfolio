<?php
$numero1 = 15;
$numero2 = 4;
$resto = $numero1 % $numero2;
$resultado = "El resto de la división entera de $numero1 entre $numero2 es $resto.";
echo "<p>$resultado</p>";
?>