<?php
$lado1 = 5;
$lado2 = 8;
$perimetro = 2 * ($lado1 + $lado2);
$resultado = "El perímetro del rectángulo de lados $lado1 y $lado2 es $perimetro.";
echo "<p>$resultado</p>";
?>