<?php
$lado = 3;
$perimetro = $lado * 4;
$resultado = "El perímetro del cuadrado de lado $lado es $perimetro.";
echo "<p>$resultado</p>";
?>