<?php
$nombre = "Pedro";
$resultado = "Hola, $nombre.";
echo "<p>$resultado</p>";
?>