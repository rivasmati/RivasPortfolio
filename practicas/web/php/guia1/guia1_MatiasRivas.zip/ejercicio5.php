<?php
$nombre = "Matias";
$apellido = "García";
$resultado = "Bienvenido, $nombre $apellido.";
echo "<p>$resultado</p>";
?>