<?php

$titulo = 'Que Hacemos';
require 'templates/header.php';
require 'includes/data.php';

?>

<h1>Que hacemos</h1>

<?php
require 'templates/footer.php';
