<?php

$titulo = 'Contacto';
require 'templates/header.php';
require 'includes/data.php';

?>

<h1>Contacto</h1>

<?php
require 'templates/footer.php';
