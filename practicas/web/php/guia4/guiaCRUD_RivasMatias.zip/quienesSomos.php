<?php

$titulo = 'Quienes Somos';
require 'templates/header.php';
require 'includes/data.php';

?>

<h1>Quienes Somos</h1>

<?php
require 'templates/footer.php';
